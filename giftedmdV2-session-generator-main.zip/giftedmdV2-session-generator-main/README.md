# GiftedmdV2-session-generator
- Kindly star my repo
- Fork and edit as you wish
- Deploy to your favourite hosting server eg Heroku or Render or self hosting

<strong>NB:<strong/> This repo also generates session ID for all bots using whiskeysockets/baileys
[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)
QR- WEB - PAIR CODE FOR BOT WITH WHISKEYSOCKETS/BAILEYS
[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)
<p align="center">
   <a href="https://github.com/Xcelsama">
    <img src="https://i.ibb.co/HtT3vjm/goku-gif-3.gif" width="500">
     
</a>
   <a aria-label="QRis free to use" href="https://whatsapp.com/channel/0029VaBcXo4JJhzW9c1uVD2X" target="_blank">
 <p align="center"><img src="https://profile-counter.glitch.me/{xcelsama}/count.svg" alt="xcelsama:: Visitor's Count" /></p>



[`ℹ️Contact Owner`](https://wa.me/+254728782591)

FORK THE REPOSITORY (Repo) 
    <br>
<a href="https://github.com/Giftedmaurice/giftedmdV2-session-generator/fork"><img title="WEB" src="https://img.shields.io/badge/FORK Gifted-QR?color=black&style=for-the-badge&logo=stackshare"></a>

Now Deploy
    <br>
<a href='https://dashboard.heroku.com/new?template=https://github.com/Giftedmaurice/giftedmdV2-session-generator' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=heroku&logoColor=white'/>
# `Owner`
 <a href="https://github.com/Giftedmaurice"><img src="https://github.com/Giftedmaurice.png" width="250" height="250" alt="Giftedmaurice"/></a>

# `Contributor` 
<a href="https://github.com/Xcelsama"><img src="https://github.com/Xcelsama.png" width="250" height="250" alt="Xcelsama"/></a>

   
